1. Generate the private key to become a local CA:

mkdir -p ~/Desktop/Tmp/certs && cd ~/Desktop/Tmp/certs;

openssl genrsa -des3 -out myCA.key 2048

!QAZ2wsx


2. Generate a root certificate:

openssl req -x509 -new -nodes -key myCA.key -sha256 -days 1825 -out myCA.pem

Country Name (2 letter code) [AU]:CN
State or Province Name (full name) [Some-State]:Liaoning            
Locality Name (eg, city) []:Dalian
Organization Name (eg, company) [Internet Widgits Pty Ltd]:SelfTestOrg     
Organizational Unit Name (eg, section) []:Dev
Common Name (e.g. server FQDN or YOUR name) []:JackZhou
Email Address []:test@gmail.com


3. Adding the Root Certificate to Linux:

sudo apt-get install -y ca-certificates

sudo cp ./certs/myCA.pem /usr/local/share/ca-certificates/myCA.crt

sudo update-ca-certificates

4. Test if the certificate has been installed

awk -v cmd='openssl x509 -noout -subject' '/BEGIN/{close(cmd)};{print | cmd}' < /etc/ssl/certs/ca-certificates.crt | grep JackZhou

5. Creating CA-Signed Certificates for Your Dev Sites

cd ~/Desktop/Tmp/certs;

openssl genrsa -out jackzhou.me.key 2048

openssl req -new -key jackzhou.me.key -out jackzhou.me.csr

You are about to be asked to enter information that will be incorporated
into your certificate request.
What you are about to enter is what is called a Distinguished Name or a DN.
There are quite a few fields but you can leave some blank
For some fields there will be a default value,
If you enter '.', the field will be left blank.
-----
Country Name (2 letter code) [AU]:CN
State or Province Name (full name) [Some-State]:Liaoning
Locality Name (eg, city) []:Dalian
Organization Name (eg, company) [Internet Widgits Pty Ltd]:SelfTestOrg
Organizational Unit Name (eg, section) []:Dev
Common Name (e.g. server FQDN or YOUR name) []:jackzhou.me
Email Address []:test@gmail.com

Please enter the following 'extra' attributes
to be sent with your certificate request
A challenge password []:!QAZ2wsx
An optional company name []:TestCompanyName

6. Create an X509 V3 certificate extension config file

vi jackzhou.me.ext
authorityKeyIdentifier=keyid,issuer
basicConstraints=CA:FALSE
keyUsage = digitalSignature, nonRepudiation, keyEncipherment, dataEncipherment
subjectAltName = @alt_names

[alt_names]
DNS.1 = jackzhou.me

:wq

openssl x509 -req -in jackzhou.me.csr -CA myCA.pem -CAkey myCA.key -CAcreateserial -out jackzhou.me.crt -days 825 -sha256 -extfile jackzhou.me.ext

Signature ok
subject=C = CN, ST = Liaoning, L = Dalian, O = SelfTestOrg, OU = Dev, CN = jackzhou.me, emailAddress = test@gmail.com
Getting CA Private Key
Enter pass phrase for myCA.key:!QAZ2wsx

7. Install mkcert
curl -JLO "https://dl.filippo.io/mkcert/latest?for=linux/amd64"
chmod +x mkcert-v*-linux-amd64
sudo cp mkcert-v*-linux-amd64 /usr/local/bin/mkcert
sudo apt install libnss3-tools
mkcert -install

The local CA is already installed in the system trust store! 👍
The local CA is now installed in the Firefox and/or Chrome/Chromium trust store (requires browser restart)! 🦊

mkcert jackzhou.me "*.jackzhou.me" localhost 127.0.0.1 ::1

Created a new certificate valid for the following names 📜
 - "jackzhou.me"
 - "*.jackzhou.me"
 - "localhost"
 - "127.0.0.1"
 - "::1"

Reminder: X.509 wildcards only go one level deep, so this won't match a.b.jackzhou.me ℹ️

The certificate is at "./jackzhou.me+4.pem" and the key at "./jackzhou.me+4-key.pem" ✅

It will expire on 4 December 2025 🗓

8. Configure Nginx:
sudo vi /etc/nginx/sites-available/default

server {
        listen 443 ssl default_server;
        listen [::]:443 ssl default_server;

        ssl_certificate /home/jack/Desktop/Tmp/certs/jackzhou.me+4.pem;
        ssl_certificate_key /home/jack/Desktop/Tmp/certs/jackzhou.me+4-key.pem;

        root /var/www/html;

        # Add index.php to the list if you are using PHP
        index index.html index.htm index.nginx-debian.html;

        server_name jackzhou.me www.jackzhou.me;

        location / {
                # First attempt to serve request as file, then
                # as directory, then fall back to displaying a 404.
                try_files $uri $uri/ =404;
        }
}

9. Enable and restart nginx
sudo systemctl enable nginx
sudo nginx -t
sudo systemctl restart nginx

