// const https = require(`https`);
// const fs = require(`fs`);

// const options = {
//  key: fs.readFileSync(`./jackzhou.me+4-key.pem`),
//  cert: fs.readFileSync(`./jackzhou.me+4.pem`)
// };

// https.createServer(options, (req, res) => {
//  res.writeHead(200);
//  res.end(`hello world\n`);
// }).listen(8443);
//

const https = require('https');
const fs = require('fs');
const ws = require('ws');
const path = require('path');
const url = require('url');
const regex = /\/send_notification\/([\w\s\d_#*@&$%,.]+)/i;

var connected_ws = null;

const server = https.createServer({
  cert: fs.readFileSync('./jackzhou.me+4.pem'),
  key: fs.readFileSync('./jackzhou.me+4-key.pem')
}, (req, res) => {
  // res.writeHead(200);
  // res.end(`hello world\n`);
  
  const matches = decodeURI(req.url).match(regex);
  if (connected_ws && matches) {
    console.log('wss received: %s', matches);
    console.log('wss notified: %s', matches[1]);
    connected_ws.send(""+ matches[1]);
    res.writeHead(200);
    const jsonContent = JSON.stringify({"Notification":matches[1], "send_status":"sent"});
    res.end(jsonContent);
  } else {
    res.writeHead(200, {"Content-Type": "text/html"});
    // res.sendFile(__dirname + "/index.html");
    fs.createReadStream(path.resolve(__dirname, 'index.html')).pipe(res);
  }
  console.log(req.url);
});

wss = new ws.WebSocketServer({ server });
wss.on('connection', function connection(ws) {
  ws.on('error', console.error);

  connected_ws = ws;

  ws.on('message', function message(data) {
    const found = ("" + data).match(regex);
    if (found != undefined) {
      console.log('wss received: %s', found);
      console.log('wss notified: %s', found[1]);
      ws.send(""+ found[1]);
    } else {
      console.log('wss received: %s', data);
      console.log('wss sendback: %s', data);
      ws.send(""+ data);
    }
  });
});

server.listen(8443);
